import torch
from PIL import Image
import pandas as pd
import time
import sys
import os

from ultralytics import YOLO
torch.cuda.empty_cache()

# Define the models to test
models = ['yolov5n','yolov8x6.pt']

# Array of image paths and real persons count
image_paths = [
    # ("/home/romh/PycharmProjects/Person_Detection/10pepole.jpg", 10),
    # ("/home/romh/PycharmProjects/Person_Detection/Familyhike.jpg", 3),
    # ("/home/romh/PycharmProjects/Person_Detection/3_kids.jpeg", 3),
    ("/home/romh/PycharmProjects/Person_Detection/19.jpg", 19),
    # ("/home/romh/PycharmProjects/Person_Detection/5.jpg", 5),
    # ("/home/romh/PycharmProjects/Person_Detection/5_2.jpg", 5),
    # ("/home/romh/PycharmProjects/Person_Detection/5_3.jpg", 5),
    # ("/home/romh/PycharmProjects/Person_Detection/4.jpg", 4),
    # ("/home/romh/PycharmProjects/Person_Detection/1.jpg", 1),
    # ("/home/romh/PycharmProjects/Person_Detection/0.jpg", 0),
]

# Resolutions to test
resolutions = [(1280, 720), (640, 640), (320, 320), (160, 160)]  # Add more resolutions if needed

# Dataframes to store detection results
dfs = []

for image_path, real_persons in image_paths:
    # Load image
    img = Image.open(image_path)

    # Prepare lists to store results for each resolution
    data = []

    for resolution in resolutions:
        # Resize the image to the current resolution
        img_resized = img.resize(resolution)

        # Convert the image to grayscale
        img_grayscale = img_resized.convert('L')

        # Prepare lists to store results for both color and grayscale images
        results_data = []
        detection_time_grayscale = 0
        person_count_grayscale = 0
        average_confidence_grayscale = 0

        for model_name in models:
            if 'v8' in model_name:
                model = YOLO(model_name)  # This assumes the YOLO constructor for v8 is similar
                model.to('cuda')
                start_time = time.time()
                results = model.predict(img_resized)  # Assuming this method exists and works for PIL images or paths
                result = results[0]
                end_time = time.time()
                detection_time_color = end_time - start_time

                # Assuming results are in a format that includes bounding boxes, confidences, and class IDs
                # You'll need to adjust this based on the actual format of your YOLOv8 results
                persons_color =  [box for box in result.boxes if box.cls[0].item() == 0]
                person_count_color = len(persons_color)
                average_confidence_color = sum([box.conf[0].item() for box in persons_color]) / person_count_color if person_count_color > 0 else 0

            # Load model
            else:
                model = torch.hub.load('ultralytics/yolov5', model_name, pretrained=True)
                # Perform inference on color image
                start_time = time.time()
                results_color = model(img_resized)
                end_time = time.time()

                # Filter for persons (class 0)
                persons_color = results_color.xyxy[0][results_color.xyxy[0][:, -1] == 0]
                # Calculate stats for color image
                detection_time_color = end_time - start_time
                person_count_color = persons_color.shape[0]
                average_confidence_color = persons_color[:, 4].mean().item() if person_count_color > 0 else 0

                # # Perform inference on grayscale image
                # start_time = time.time()
                # results_grayscale = model(img_grayscale)
                # end_time = time.time()
                #
                # # Filter for persons (class 0)
                # persons_grayscale = results_grayscale.xyxy[0][results_grayscale.xyxy[0][:, -1] == 0]
                #
                # # Calculate stats for grayscale image
                # detection_time_grayscale = end_time - start_time
                # person_count_grayscale = persons_grayscale.shape[0]
                # average_confidence_grayscale = persons_grayscale[:,
                #                                4].mean().item() if person_count_grayscale > 0 else 0

            # Store results for the current model in results_data
            results_data.append({
                'Model': model_name,
                'Resolution': f'{resolution[0]}x{resolution[1]}',
                'Detection Time (Color)': detection_time_color,
                'Number of Persons Detected (Color)': person_count_color,
                'Delta_color': abs(real_persons - person_count_color),
                'Average Confidence (Color)': average_confidence_color,
                'Detection Time (Grayscale)': detection_time_grayscale,
                'Number of Persons Detected (Grayscale)': person_count_grayscale,
                'Average Confidence (Grayscale)': average_confidence_grayscale,
                'Delta_gray': abs(real_persons - person_count_grayscale),
            })

        # Add the results_data to the data list
        data.extend(results_data)

    # Create dataframe for the current image
    df = pd.DataFrame(data)
    dfs.append(df)

# Concatenate dataframes for all images
all_df = pd.concat(dfs)

# Save dataframe to CSV file
all_df.to_csv('detection_results_all_images.csv', index=False)
# Now, to find the best line according to your specific criteria:
# 1. Smallest Delta_color
# 2. Highest Average Confidence (Color)
# 3. Smallest Detection Time (Color)


# We first sort by 'Detection Time (Color)' and 'Delta_color' in ascending order,
# and then 'Average Confidence (Color)' in descending order to prioritize the highest confidence.
sorted_df = all_df.sort_values(by=['Delta_color', 'Average Confidence (Color)','Detection Time (Color)'], ascending=[True, True, False])

# The first row after sorting will be your optimal choice based on the criteria
optimal_entry = sorted_df.iloc[0]

print("Optimal Model and Resolution:")
print(optimal_entry[['Model', 'Resolution', 'Detection Time (Color)', 'Delta_color', 'Average Confidence (Color)']])
