import cv2
from ultralytics import YOLO

# Load a model
model = YOLO('yolov8n-cls.pt')  # Load an official model
model.to('cuda')  # Move model to GPU

# Read and process the image
image_path = '/home/romh/PycharmProjects/Person_Detection/19.jpg'
img = cv2.imread(image_path)
img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

# Run inference
results = model.predict(img, conf=0.5, classes=0)  # Detect persons (class ID 0)

# Check if results are valid
if results is not None and len(results) > 0 and results[0] is not None and len(results[0].boxes) > 0:
    # Check if any detections are found
    persons = [box for box in results[0].boxes if box.cls[0].item() == 0]

    if len(persons) > 0:
        for person in persons:
            x1, y1, x2, y2 = person.xyxy[0].tolist()
            cv2.rectangle(img, (int(x1), int(y1)), (int(x2), int(y2)), (0, 255, 0), 2)

        # Display the image
        cv2.imshow('Detected Persons', img)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
    else:
        print("No persons detected.")
else:
    print("No detections found.")
