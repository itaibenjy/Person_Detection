from ultralytics import YOLO

# Define the models to test
models = ['']
model = YOLO("yolov8n.pt")
results = model.predict("https://ultralytics.com/images/zidane.jpg")
result = results[0]
#filter for persons (class 0)
persons = [box for box in result.boxes if box.cls[0].item() == 0]
print(len(persons))
for box in result.boxes:
  class_id = result.names[box.cls[0].item()]
  cords = box.xyxy[0].tolist()
  cords = [round(x) for x in cords]
  conf = round(box.conf[0].item(), 2)
  print("Object type:", class_id)
  print("Coordinates:", cords)
  print("Probability:", conf)
  print("---")
