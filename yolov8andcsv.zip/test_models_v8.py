import time
from PIL import Image, ImageDraw
import matplotlib.pyplot as plt
from torchvision import models, transforms
import torch
from ultralytics import YOLO  # Correct import for YOLOv8
import torch
print(torch.cuda.is_available())  # Should return True if CUDA is properly set up
torch.backends.cudnn.benchmark = True
device: str = "cuda" if torch.cuda.is_available() else "cpu"
print(device)  # Should return 'cuda' if CUDA is properly set up
# Load a pre-trained ResNet50 model
resnet50 = models.resnet50(pretrained=True)
resnet50.eval()  # Set to evaluation mode

# Define transformation for input images
transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
])

# Define the models to test, including YOLOv8
models = ['yolov8s', 'yolov8n', 'yolov8m', 'yolov8l', 'yolov8x']

# Image to test
image_path = "/home/romh/PycharmProjects/Person_Detection/10pepole.jpg"
original_img = Image.open(image_path)
width, height = original_img.size
title = f'{width}x{height} {image_path.split("/")[-1].split(".")[0]}'

# Stats storage
detection_times = []
person_counts = []
average_confidences = []
feature_vectors = []  # Store feature vectors for detected persons

# Adjust for single or multiple models
fig_img, axs_img = plt.subplots(1, len(models), figsize=(20, 10)) if len(models) > 1 else plt.subplots(figsize=(20, 10))
axs_img = [axs_img] if len(models) == 1 else axs_img

fig_img.suptitle(f'Output Images for Different Models {title}', fontsize=16)

for i, model_name in enumerate(models):
    img = original_img.copy()  # Work with a copy of the original image
    draw = ImageDraw.Draw(img)  # Create a drawing context

    if 'yolov8' in model_name:
        model = YOLO("yolov8n.pt")
        print(f'Model running on device: {next(model.parameters()).device}')  # Check device of the model

        model.to(device)  # Move the model to the GPU
        print(f'Model running on device: {next(model.parameters()).device}')  # Check device of the model again

        time.sleep(1)  # YOLOv8 needs a warm-up
        start_time = time.time()
        results = model.predict(image_path,classes=0)
        end_time = time.time()
        result = results[0]
        detection_time = sum(result.speed.values())
        persons = [box for box in result.boxes if box.cls[0].item() == 0]

        # Draw detection boxes on the image
        for box in persons:
            draw.rectangle(box.xyxy[0].tolist(), outline="red", width=4)

    person_count = len(persons)
    average_confidence = sum(box.conf[0].item() for box in persons) / len(persons) if persons else 0

    # Extract features for the first person detected (as an example)
    if persons:
        # Transform and add batch dimension
        cropped_img = original_img.crop(persons[0].xyxy[0].tolist())
        cropped_img_tensor = transform(cropped_img).unsqueeze(0)

        with torch.no_grad():
            features = resnet50(cropped_img_tensor)

        # Optionally, you could store features for later use
        feature_vectors.append(features)

    detection_times.append(detection_time)
    person_counts.append(person_count)
    average_confidences.append(average_confidence)

    axs = axs_img[i]
    axs.imshow(img)
    axs.axis('off')
    axs.set_title(f"{model_name}\nDetection Time: {detection_time:.2f}s\nPersons Detected: {person_count}")
    print(f"feture_vectors: {feature_vectors}")
plt.tight_layout(rect=[0, 0.03, 1, 0.97])
plt.show()
