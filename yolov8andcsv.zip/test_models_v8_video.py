import time

import cv2
import torch
from ultralytics import YOLO  # Assuming this is the correct import based on your context


device: str = "cuda" if torch.cuda.is_available() else "cpu"

# Open a video file
video_path = '/home/romh/PycharmProjects/Person_Detection/pexels-boyan-minchev-12234321 (2160p).mp4'
cap = cv2.VideoCapture(video_path)

# Get video properties
frame_width = int(cap.get(3))
frame_height = int(cap.get(4))
frame_rate = int(cap.get(cv2.CAP_PROP_FPS))
video_length = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

total_confidences = 0
detections_count = 0

fourcc = cv2.VideoWriter_fourcc(*'mp4v')  # For MP4 output
output_path = 'output.mp4'
out = cv2.VideoWriter(output_path, fourcc, frame_rate, (frame_width, frame_height))
model_name = 'yolov8n'  # Choose the appropriate model variant
start_time = time.time()
model = YOLO(model_name)
print(f'Before set to cuda , Model running on device: {next(model.parameters()).device}')  # Check device of the model
# model.to(device)  # Move the model to the GPU
print(f'Model running on device: {next(model.parameters()).device}')  # Check device of the model again
detection_time = 0
while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    # Convert the frame to the format expected by YOLOv8
    results = model.predict(frame)
    result = results[0]
    detection_time += sum(result.speed.values())

    # Draw bounding boxes and add class labels and probabilities
    for det in results[0].boxes:  # Loop over each detection
        x1, y1, x2, y2 = det.xyxy[0].tolist()
        cls = det.cls[0].item()  # Get class ID
        prob = det.conf[0].item()  # Get probability
        label = f'{model.names[int(cls)]}: {prob:.2f}'  # Construct label
        total_confidences += prob

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
average_confidence = total_confidences / detections_count if detections_count else 0
end_time = time.time() - start_time

print(f'Model running on device: {next(model.parameters()).device} , total frames: {video_length} , total time: {end_time:.2f}s')
print(f'Video resolution: {frame_width}x{frame_height}')
print(f'Video frame rate: {frame_rate} fps')
print(f'Video length: {video_length} frames , in seconds: {video_length/frame_rate} seconds')
print(f"Detection time: {detection_time:.2f}ms in seconds: {detection_time/1000:.2f}s , for each frame average: {detection_time/video_length:.2f}ms")
print(f'Average Confidence: {average_confidence:.2f}')

# Release everything if job is finished
cap.release()
# out.release()
cv2.destroyAllWindows()
